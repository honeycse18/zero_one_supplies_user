import 'product_return.dart';

class AuctionProductDeliveryInfo {
  int? delivery;
  int? shipping;
  AuctionProductDeliveryInfoProductReturn? productReturn;

  AuctionProductDeliveryInfo(
      {this.delivery, this.shipping, this.productReturn});

  factory AuctionProductDeliveryInfo.fromJson(Map<String, dynamic> json) =>
      AuctionProductDeliveryInfo(
        delivery: json['delivery'] as int?,
        shipping: json['shipping'] as int?,
        productReturn: json['product_return'] == null
            ? null
            : AuctionProductDeliveryInfoProductReturn.fromJson(
                json['product_return'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        'delivery': delivery,
        'shipping': shipping,
        'product_return': productReturn?.toJson(),
      };
}
