import 'discount_value.dart';
import 'product.dart';

class AuctionProductRelatedProduct {
  String? id;
  String? name;
  int? price;
  bool? newArrival;
  bool? isAuction;
  DateTime? createdAt;
  String? image;
  int? rating;
  bool? discount;
  AuctionProductRelatedProductDiscountValue? discountValue;
  int? currentPrice;
  bool? isFavorite;
  DateTime? startDate;
  DateTime? endDate;
  bool? isEnd;
  AuctionProductRelatedProductProduct? product;
  int? currentAuctionPrice;

  AuctionProductRelatedProduct({
    this.id,
    this.name,
    this.price,
    this.newArrival,
    this.isAuction,
    this.createdAt,
    this.image,
    this.rating,
    this.discount,
    this.discountValue,
    this.currentPrice,
    this.isFavorite,
    this.startDate,
    this.endDate,
    this.isEnd,
    this.product,
    this.currentAuctionPrice,
  });

  factory AuctionProductRelatedProduct.fromJson(Map<String, dynamic> json) {
    return AuctionProductRelatedProduct(
      id: json['_id'] as String?,
      name: json['name'] as String?,
      price: json['price'] as int?,
      newArrival: json['new_arrival'] as bool?,
      isAuction: json['is_auction'] as bool?,
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
      image: json['image'] as String?,
      rating: json['rating'] as int?,
      discount: json['discount'] as bool?,
      discountValue: json['discount_value'] == null
          ? null
          : AuctionProductRelatedProductDiscountValue.fromJson(
              json['discount_value'] as Map<String, dynamic>),
      currentPrice: json['current_price'] as int?,
      isFavorite: json['isFavorite'] as bool?,
      startDate: json['start_date'] == null
          ? null
          : DateTime.parse(json['start_date'] as String),
      endDate: json['end_date'] == null
          ? null
          : DateTime.parse(json['end_date'] as String),
      isEnd: json['is_end'] as bool?,
      product: json['product'] == null
          ? null
          : AuctionProductRelatedProductProduct.fromJson(
              json['product'] as Map<String, dynamic>),
      currentAuctionPrice: json['current_auction_price'] as int?,
    );
  }

  Map<String, dynamic> toJson() => {
        '_id': id,
        'name': name,
        'price': price,
        'new_arrival': newArrival,
        'is_auction': isAuction,
        'createdAt': createdAt?.toIso8601String(),
        'image': image,
        'rating': rating,
        'discount': discount,
        'discount_value': discountValue?.toJson(),
        'current_price': currentPrice,
        'isFavorite': isFavorite,
        'start_date': startDate?.toIso8601String(),
        'end_date': endDate?.toIso8601String(),
        'is_end': isEnd,
        'product': product?.toJson(),
        'current_auction_price': currentAuctionPrice,
      };
}
