import 'attribute.dart';
import 'auction_info.dart';
import 'brand.dart';
import 'category.dart';
import 'delivery_info.dart';
import 'description.dart';
import 'product_location.dart';
import 'quantity.dart';
import 'related_product.dart';
import 'specifications.dart';
import 'store.dart';
import 'subcategory.dart';

class AuctionProductDetails {
  String? id;
  Store? store;
  String? name;
  String? model;
  List<AuctionProductCategory>? categories;
  List<AuctionProductSubcategory>? subcategories;
  AuctionProductQuantity? quantity;
  List<String>? tags;
  List<String>? galleryImages;
  bool? stockAvailable;
  bool? stockVisibility;
  bool? flashDeal;
  bool? newArrival;
  bool? userRequested;
  bool? isStatus;
  List<dynamic>? quantityBasedPrice;
  List<AuctionProductAttribute>? attribute;
  DateTime? createdAt;
  DateTime? updatedAt;
  AuctionProductBrand? brand;
  String? unit;
  AuctionProductLocation? productLocation;
  AuctionProductDescription? description;
  String? specificationDescription;
  String? productImage;
  String? thumbImage;
  AuctionProductDeliveryInfo? deliveryInfo;
  List<AuctionProductRelatedProduct>? relatedProducts;
  AuctionProductSpecifications? specifications;
  AuctionProductAuctionInfo? auctionInfo;
  bool? isFavorite;

  AuctionProductDetails({
    this.id,
    this.store,
    this.name,
    this.model,
    this.categories,
    this.subcategories,
    this.quantity,
    this.tags,
    this.galleryImages,
    this.stockAvailable,
    this.stockVisibility,
    this.flashDeal,
    this.newArrival,
    this.userRequested,
    this.isStatus,
    this.quantityBasedPrice,
    this.attribute,
    this.createdAt,
    this.updatedAt,
    this.brand,
    this.unit,
    this.productLocation,
    this.description,
    this.specificationDescription,
    this.productImage,
    this.thumbImage,
    this.deliveryInfo,
    this.relatedProducts,
    this.specifications,
    this.auctionInfo,
    this.isFavorite,
  });

  factory AuctionProductDetails.fromJson(Map<String, dynamic> json) =>
      AuctionProductDetails(
        id: json['_id'] as String?,
        store: json['store'] == null
            ? null
            : Store.fromJson(json['store'] as Map<String, dynamic>),
        name: json['name'] as String?,
        model: json['model'] as String?,
        categories: (json['categories'] as List<dynamic>?)
            ?.map((e) =>
                AuctionProductCategory.fromJson(e as Map<String, dynamic>))
            .toList(),
        subcategories: (json['subcategories'] as List<dynamic>?)
            ?.map((e) =>
                AuctionProductSubcategory.fromJson(e as Map<String, dynamic>))
            .toList(),
        quantity: json['quantity'] == null
            ? null
            : AuctionProductQuantity.fromJson(
                json['quantity'] as Map<String, dynamic>),
        tags: json['tags'] as List<String>?,
        galleryImages: json['gallery_images'] as List<String>?,
        stockAvailable: json['stock_available'] as bool?,
        stockVisibility: json['stock_visibility'] as bool?,
        flashDeal: json['flash_deal'] as bool?,
        newArrival: json['new_arrival'] as bool?,
        userRequested: json['user_requested'] as bool?,
        isStatus: json['is_status'] as bool?,
        quantityBasedPrice: json['quantity_based_price'] as List<dynamic>?,
        attribute: (json['attribute'] as List<dynamic>?)
            ?.map((e) =>
                AuctionProductAttribute.fromJson(e as Map<String, dynamic>))
            .toList(),
        createdAt: json['createdAt'] == null
            ? null
            : DateTime.parse(json['createdAt'] as String),
        updatedAt: json['updatedAt'] == null
            ? null
            : DateTime.parse(json['updatedAt'] as String),
        brand: json['brand'] == null
            ? null
            : AuctionProductBrand.fromJson(
                json['brand'] as Map<String, dynamic>),
        unit: json['unit'] as String?,
        productLocation: json['product_location'] == null
            ? null
            : AuctionProductLocation.fromJson(
                json['product_location'] as Map<String, dynamic>),
        description: json['description'] == null
            ? null
            : AuctionProductDescription.fromJson(
                json['description'] as Map<String, dynamic>),
        specificationDescription: json['specification_description'] as String?,
        productImage: json['product_image'] as String?,
        thumbImage: json['thumb_image'] as String?,
        deliveryInfo: json['delivery_info'] == null
            ? null
            : AuctionProductDeliveryInfo.fromJson(
                json['delivery_info'] as Map<String, dynamic>),
        relatedProducts: (json['related_products'] as List<dynamic>?)
            ?.map((e) => AuctionProductRelatedProduct.fromJson(
                e as Map<String, dynamic>))
            .toList(),
        specifications: json['specifications'] == null
            ? null
            : AuctionProductSpecifications.fromJson(
                json['specifications'] as Map<String, dynamic>),
        auctionInfo: json['auction_info'] == null
            ? null
            : AuctionProductAuctionInfo.fromJson(
                json['auction_info'] as Map<String, dynamic>),
        isFavorite: json['isFavorite'] as bool?,
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'store': store?.toJson(),
        'name': name,
        'model': model,
        'categories': categories?.map((e) => e.toJson()).toList(),
        'subcategories': subcategories?.map((e) => e.toJson()).toList(),
        'quantity': quantity?.toJson(),
        'tags': tags,
        'gallery_images': galleryImages,
        'stock_available': stockAvailable,
        'stock_visibility': stockVisibility,
        'flash_deal': flashDeal,
        'new_arrival': newArrival,
        'user_requested': userRequested,
        'is_status': isStatus,
        'quantity_based_price': quantityBasedPrice,
        'attribute': attribute?.map((e) => e.toJson()).toList(),
        'createdAt': createdAt?.toIso8601String(),
        'updatedAt': updatedAt?.toIso8601String(),
        'brand': brand?.toJson(),
        'unit': unit,
        'product_location': productLocation?.toJson(),
        'description': description?.toJson(),
        'specification_description': specificationDescription,
        'product_image': productImage,
        'thumb_image': thumbImage,
        'delivery_info': deliveryInfo?.toJson(),
        'related_products': relatedProducts?.map((e) => e.toJson()).toList(),
        'specifications': specifications?.toJson(),
        'auction_info': auctionInfo?.toJson(),
        'isFavorite': isFavorite,
      };
}
