class Info {
  String? id;
  String? logo;
  String? name;

  Info({this.id, this.logo, this.name});

  factory Info.fromJson(Map<String, dynamic> json) => Info(
        id: json['_id'] as String?,
        logo: json['logo'] as String?,
        name: json['name'] as String?,
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'logo': logo,
        'name': name,
      };
}
