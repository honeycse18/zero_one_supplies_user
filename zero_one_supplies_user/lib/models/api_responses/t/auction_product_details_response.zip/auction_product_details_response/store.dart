import 'info.dart';
import 'product.dart';

class Store {
  List<AuctionProductRelatedProductProduct>? products;
  Info? info;

  Store({this.products, this.info});

  factory Store.fromJson(Map<String, dynamic> json) => Store(
        products: (json['products'] as List<dynamic>?)
            ?.map((e) => AuctionProductRelatedProductProduct.fromJson(
                e as Map<String, dynamic>))
            .toList(),
        info: json['info'] == null
            ? null
            : Info.fromJson(json['info'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        'products': products?.map((e) => e.toJson()).toList(),
        'info': info?.toJson(),
      };
}
