import 'location.dart';

class AuctionProductLocationReplayPoint {
  AuctionProductLocationReplayPointLocation? location;
  String? id;
  String? name;
  String? address;

  AuctionProductLocationReplayPoint(
      {this.location, this.id, this.name, this.address});

  factory AuctionProductLocationReplayPoint.fromJson(
          Map<String, dynamic> json) =>
      AuctionProductLocationReplayPoint(
        location: json['location'] == null
            ? null
            : AuctionProductLocationReplayPointLocation.fromJson(
                json['location'] as Map<String, dynamic>),
        id: json['_id'] as String?,
        name: json['name'] as String?,
        address: json['address'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'location': location?.toJson(),
        '_id': id,
        'name': name,
        'address': address,
      };
}
