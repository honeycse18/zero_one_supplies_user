class AuctionProductLocationReplayPointLocation {
  double? latitude;
  double? longitude;

  AuctionProductLocationReplayPointLocation({this.latitude, this.longitude});

  factory AuctionProductLocationReplayPointLocation.fromJson(
          Map<String, dynamic> json) =>
      AuctionProductLocationReplayPointLocation(
        latitude: (json['latitude'] as num?)?.toDouble(),
        longitude: (json['longitude'] as num?)?.toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'latitude': latitude,
        'longitude': longitude,
      };
}
