import 'package:ecomik/utils/helpers/api_helper.dart';

class AuctionProductSubcategory {
  String id;
  String name;

  AuctionProductSubcategory({this.id = '', this.name = ''});

  factory AuctionProductSubcategory.fromJson(Map<String, dynamic> json) =>
      AuctionProductSubcategory(
        id: APIHelper.getSafeStringValue(json['_id']),
        name: APIHelper.getSafeStringValue(json['name']),
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'name': name,
      };
}
