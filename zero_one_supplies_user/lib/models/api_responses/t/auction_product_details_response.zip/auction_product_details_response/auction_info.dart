class AuctionProductAuctionInfo {
  String? id;
  DateTime? startDate;
  DateTime? endDate;
  bool? isEnd;
  int? currentPrice;
  DateTime? createdAt;
  DateTime? updatedAt;
  List<dynamic>? bidUsers;
  bool? isBid;

  AuctionProductAuctionInfo({
    this.id,
    this.startDate,
    this.endDate,
    this.isEnd,
    this.currentPrice,
    this.createdAt,
    this.updatedAt,
    this.bidUsers,
    this.isBid,
  });

  factory AuctionProductAuctionInfo.fromJson(Map<String, dynamic> json) =>
      AuctionProductAuctionInfo(
        id: json['_id'] as String?,
        startDate: json['start_date'] == null
            ? null
            : DateTime.parse(json['start_date'] as String),
        endDate: json['end_date'] == null
            ? null
            : DateTime.parse(json['end_date'] as String),
        isEnd: json['is_end'] as bool?,
        currentPrice: json['current_price'] as int?,
        createdAt: json['createdAt'] == null
            ? null
            : DateTime.parse(json['createdAt'] as String),
        updatedAt: json['updatedAt'] == null
            ? null
            : DateTime.parse(json['updatedAt'] as String),
        bidUsers: json['bid_users'] as List<dynamic>?,
        isBid: json['is_bid'] as bool?,
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'start_date': startDate?.toIso8601String(),
        'end_date': endDate?.toIso8601String(),
        'is_end': isEnd,
        'current_price': currentPrice,
        'createdAt': createdAt?.toIso8601String(),
        'updatedAt': updatedAt?.toIso8601String(),
        'bid_users': bidUsers,
        'is_bid': isBid,
      };
}
