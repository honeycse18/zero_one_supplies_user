import 'replay_point.dart';

class AuctionProductLocation {
  String? type;
  AuctionProductLocationReplayPoint? replayPoint;

  AuctionProductLocation({this.type, this.replayPoint});

  factory AuctionProductLocation.fromJson(Map<String, dynamic> json) {
    return AuctionProductLocation(
      type: json['type'] as String?,
      replayPoint: json['replay_point'] == null
          ? null
          : AuctionProductLocationReplayPoint.fromJson(
              json['replay_point'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() => {
        'type': type,
        'replay_point': replayPoint?.toJson(),
      };
}
