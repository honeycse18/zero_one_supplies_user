class AuctionProductQuantity {
  int? unitQuantity;
  int? stockQuantity;
  int? minPurchaseQuantity;
  int? stockAlertQuantity;

  AuctionProductQuantity({
    this.unitQuantity,
    this.stockQuantity,
    this.minPurchaseQuantity,
    this.stockAlertQuantity,
  });

  factory AuctionProductQuantity.fromJson(Map<String, dynamic> json) =>
      AuctionProductQuantity(
        unitQuantity: json['unit_quantity'] as int?,
        stockQuantity: json['stock_quantity'] as int?,
        minPurchaseQuantity: json['min_purchase_quantity'] as int?,
        stockAlertQuantity: json['stock_alert_quantity'] as int?,
      );

  Map<String, dynamic> toJson() => {
        'unit_quantity': unitQuantity,
        'stock_quantity': stockQuantity,
        'min_purchase_quantity': minPurchaseQuantity,
        'stock_alert_quantity': stockAlertQuantity,
      };
}
