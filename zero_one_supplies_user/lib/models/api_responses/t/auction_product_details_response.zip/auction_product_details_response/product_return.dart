class AuctionProductDeliveryInfoProductReturn {
  int? days;
  String? msg;

  AuctionProductDeliveryInfoProductReturn({this.days, this.msg});

  factory AuctionProductDeliveryInfoProductReturn.fromJson(
          Map<String, dynamic> json) =>
      AuctionProductDeliveryInfoProductReturn(
        days: json['days'] as int?,
        msg: json['msg'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'days': days,
        'msg': msg,
      };
}
