class AuctionProductDescription {
  String? short;
  String? long;

  AuctionProductDescription({this.short, this.long});

  factory AuctionProductDescription.fromJson(Map<String, dynamic> json) =>
      AuctionProductDescription(
        short: json['short'] as String?,
        long: json['long'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'short': short,
        'long': long,
      };
}
