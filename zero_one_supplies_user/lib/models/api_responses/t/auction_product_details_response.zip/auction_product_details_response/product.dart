import 'discount_value.dart';

class AuctionProductRelatedProductProduct {
  String? id;
  String? name;
  int? price;
  bool? newArrival;
  DateTime? createdAt;
  String? image;
  int? rating;
  bool? discount;
  AuctionProductRelatedProductDiscountValue? discountValue;
  int? currentPrice;

  AuctionProductRelatedProductProduct({
    this.id,
    this.name,
    this.price,
    this.newArrival,
    this.createdAt,
    this.image,
    this.rating,
    this.discount,
    this.discountValue,
    this.currentPrice,
  });

  factory AuctionProductRelatedProductProduct.fromJson(
          Map<String, dynamic> json) =>
      AuctionProductRelatedProductProduct(
        id: json['_id'] as String?,
        name: json['name'] as String?,
        price: json['price'] as int?,
        newArrival: json['new_arrival'] as bool?,
        createdAt: json['createdAt'] == null
            ? null
            : DateTime.parse(json['createdAt'] as String),
        image: json['image'] as String?,
        rating: json['rating'] as int?,
        discount: json['discount'] as bool?,
        discountValue: json['discount_value'] == null
            ? null
            : AuctionProductRelatedProductDiscountValue.fromJson(
                json['discount_value'] as Map<String, dynamic>),
        currentPrice: json['current_price'] as int?,
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'name': name,
        'price': price,
        'new_arrival': newArrival,
        'createdAt': createdAt?.toIso8601String(),
        'image': image,
        'rating': rating,
        'discount': discount,
        'discount_value': discountValue?.toJson(),
        'current_price': currentPrice,
      };
}
