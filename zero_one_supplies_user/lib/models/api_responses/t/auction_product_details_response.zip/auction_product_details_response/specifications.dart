class AuctionProductSpecifications {
  AuctionProductSpecifications();

  factory AuctionProductSpecifications.fromJson(Map<String, dynamic> json) {
    // TODO: implement fromJson
    throw UnimplementedError(
        'Specifications.fromJson($json) is not implemented');
  }

  Map<String, dynamic> toJson() {
    // TODO: implement toJson
    throw UnimplementedError();
  }
}
