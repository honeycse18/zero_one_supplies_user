class AuctionProductBrand {
  String? id;
  String? name;

  AuctionProductBrand({this.id, this.name});

  factory AuctionProductBrand.fromJson(Map<String, dynamic> json) =>
      AuctionProductBrand(
        id: json['_id'] as String?,
        name: json['name'] as String?,
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'name': name,
      };
}
