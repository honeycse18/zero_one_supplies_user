import 'data.dart';

class AuctionProductDetailsResponse {
  bool? error;
  String? msg;
  AuctionProductDetails? data;

  AuctionProductDetailsResponse({this.error, this.data, this.msg});

  factory AuctionProductDetailsResponse.fromJson(Map<String, dynamic> json) {
    return AuctionProductDetailsResponse(
      error: json['error'] as bool?,
      msg: json['msg'] as String?,
      data: json['data'] == null
          ? null
          : AuctionProductDetails.fromJson(
              json['data'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() => {
        'error': error,
        'msg': msg,
        'data': data?.toJson(),
      };
}
