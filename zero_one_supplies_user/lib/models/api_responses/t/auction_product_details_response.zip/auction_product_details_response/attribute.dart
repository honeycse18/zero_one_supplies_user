import 'option.dart';

class AuctionProductAttribute {
  String? key;
  List<AuctionProductAttributeOption>? options;
  String? id;

  AuctionProductAttribute({this.key, this.options, this.id});

  factory AuctionProductAttribute.fromJson(Map<String, dynamic> json) =>
      AuctionProductAttribute(
        key: json['key'] as String?,
        options: (json['options'] as List<dynamic>?)
            ?.map((e) => AuctionProductAttributeOption.fromJson(
                e as Map<String, dynamic>))
            .toList(),
        id: json['_id'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'key': key,
        'options': options?.map((e) => e.toJson()).toList(),
        '_id': id,
      };
}
