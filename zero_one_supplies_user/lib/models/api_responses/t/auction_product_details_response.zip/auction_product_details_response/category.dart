class AuctionProductCategory {
  String? id;
  String? name;

  AuctionProductCategory({this.id, this.name});

  factory AuctionProductCategory.fromJson(Map<String, dynamic> json) =>
      AuctionProductCategory(
        id: json['_id'] as String?,
        name: json['name'] as String?,
      );

  Map<String, dynamic> toJson() => {
        '_id': id,
        'name': name,
      };
}
