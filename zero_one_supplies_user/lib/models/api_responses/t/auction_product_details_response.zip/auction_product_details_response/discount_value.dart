class AuctionProductRelatedProductDiscountValue {
  AuctionProductRelatedProductDiscountValue();

  factory AuctionProductRelatedProductDiscountValue.fromJson(
      Map<String, dynamic> json) {
    // TODO: implement fromJson
    throw UnimplementedError(
        'DiscountValue.fromJson($json) is not implemented');
  }

  Map<String, dynamic> toJson() {
    // TODO: implement toJson
    throw UnimplementedError();
  }
}
