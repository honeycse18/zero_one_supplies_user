class AuctionProductAttributeOption {
  String? label;
  int? price;
  String? id;

  AuctionProductAttributeOption({this.label, this.price, this.id});

  factory AuctionProductAttributeOption.fromJson(Map<String, dynamic> json) =>
      AuctionProductAttributeOption(
        label: json['label'] as String?,
        price: json['price'] as int?,
        id: json['_id'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'label': label,
        'price': price,
        '_id': id,
      };
}
